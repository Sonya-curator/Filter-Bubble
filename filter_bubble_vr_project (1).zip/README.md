# Filter Bubble VR Project

This is a starter A-Frame VR exhibition for the Filter Bubble project. It features a central hub with teleportation-enabled zones for different social media platforms.

## How to Host on GitHub Pages

1. Create a GitHub account and a new repository (e.g., `filter-bubble-vr`).
2. Upload the contents of this ZIP file to the repository.
3. Rename `index.html` to be the main entry point.
4. Go to **Settings > Pages** in your repository.
5. Under **Source**, select the `main` branch and `/root` folder.
6. Click **Save**. Your site will be live at `https://yourusername.github.io/filter-bubble-vr`.

## Platforms Included

- Instagram
- TikTok
- YouTube

You can add more rooms by duplicating the HTML structure and updating the teleportation links.
